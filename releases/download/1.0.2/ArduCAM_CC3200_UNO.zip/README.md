# cc3200-core
