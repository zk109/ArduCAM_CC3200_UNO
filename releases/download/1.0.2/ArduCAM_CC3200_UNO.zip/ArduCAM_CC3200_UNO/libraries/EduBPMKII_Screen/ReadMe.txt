    LCD_protocol100
    Project
    ----------------------------------
    Developed with embedXcode

    Project LCD_protocol100
    Created by Rei VILO on 05/10/13
    Copyright © 2013 http://embeddedcomputing.weebly.com

    Dual license:
    * For hobbyists and for personal usage:
        Attribution-NonCommercial-ShareAlike 3.0 Unported (CC BY-NC-SA 3.0)

    * For professionals or organisations or for commercial usage:
        All rights reserved

    For any enquiry about license
        http://embeddedcomputing.weebly.com/contact


    References
    ----------------------------------
    http://embeddedcomputing.weebly.com/lcd_screen-library-suite.html


    embedXcode
    embedXcode+
    ----------------------------------
    Embedded Computing on Xcode
    Copyright © Rei VILO, 2010-2013
    All rights reserved
    http://embedXcode.weebly.com

